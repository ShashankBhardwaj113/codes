var EmployeeModel = require("../models/employee");

const EmployeeController = {};

EmployeeController.insertEmployee = (req, res, next) => {
  //Fill in the code
  // var employee = new Employee(req.body);
  var employee = EmployeeModel.insertEmployee(req.body);
  employee
    .save()
    .then(() => res.status(201).send(employee))
    .catch((e) => res.status(400).send(e));
};

EmployeeController.getAllEmployees = (req, res, next) => {
  //Fill in the code
  var employees = EmployeeModel.getAll();
  employees
    .find({})
    .then((employees) => res.send(employees))
    .catch((e) => res.status(500).send());
};

module.exports = EmployeeController;
